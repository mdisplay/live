A Pen created at CodePen.io. You can find this one at http://codepen.io/rodnylobos/pen/KoJxq.

 studies on Snap SVG